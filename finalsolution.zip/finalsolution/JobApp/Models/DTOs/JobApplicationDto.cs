﻿using System.ComponentModel.DataAnnotations;
namespace JobApp.Models.DTOs
{
    public class JobApplicationDto
    {
        public int Id { get; set; }
        public string Company { get; set; }
        public string Position { get; set; }
        public JobStatus Status { get; set; }
        public DateTime DateApplied { get; set; }
        public DateTime LastUpdated { get; set; }
        public string Notes { get; set; }

    }
    public class CreateJobApplicationDto
    {
        [Required]
        public string Company { get; set; }

        [Required]
        public string Position { get; set; }

        [Required]
        public JobStatus Status { get; set; }

        public DateTime DateApplied { get; set; } = DateTime.UtcNow;

        public string Notes { get; set; }
    }

    public class UpdateJobApplicationDto
    {
        public JobStatus Status { get; set; }
        public string Notes { get; set; }
    }

}
