﻿namespace JobApp.Models
{
    public class JobApplication
    {
        public int Id { get; set; }
        public string Company { get; set; }
        public string Position { get; set; }
        public JobStatus Status { get; set; }
        public DateTime DateApplied { get; set; }
        public DateTime LastUpdated { get; set; }
        public string Notes { get; set; }
        public string UserId { get; set; }
        public AppUser User { get; set; }
    }
    public enum JobStatus
    {
        Applied,
        PhoneScreening,
        Interview,
        TechnicalInterview,
        Offer,
        Rejected,
        Accepted,
        Withdrawn
    }



}
