﻿using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using JobApp.Data;
using JobApp.Models.DTOs;
using JobApp.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;
using Microsoft.EntityFrameworkCore;



namespace JobApp.Controllers
{
    [Authorize]
    [ApiController]
    [Route("api/[controller]")]
    public class JobApplicationsController : ControllerBase
    {
        private readonly ApplicationDbContext _context;

        public JobApplicationsController(ApplicationDbContext context)
        {
            _context = context;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<JobApplicationDto>>> GetJobApplications()
        {
            var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);

            var applications = await _context.JobApplications
                .Where(j => j.UserId == userId)
                .OrderByDescending(j => j.LastUpdated)
                .Select(j => new JobApplicationDto
                {
                    Id = j.Id,
                    Company = j.Company,
                    Position = j.Position,
                    Status = j.Status,
                    DateApplied = j.DateApplied,
                    LastUpdated = j.LastUpdated,
                    Notes = j.Notes
                })
                .ToListAsync();

            return applications;
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<JobApplicationDto>> GetJobApplication(int id)
        {
            var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);

            var jobApplication = await _context.JobApplications
                .Where(j => j.Id == id && j.UserId == userId)
                .Select(j => new JobApplicationDto
                {
                    Id = j.Id,
                    Company = j.Company,
                    Position = j.Position,
                    Status = j.Status,
                    DateApplied = j.DateApplied,
                    LastUpdated = j.LastUpdated,
                    Notes = j.Notes
                })
                .FirstOrDefaultAsync();

            if (jobApplication == null)
            {
                return NotFound();
            }

            return jobApplication;
        }

        [HttpPost]
        public async Task<ActionResult<JobApplicationDto>> CreateJobApplication(CreateJobApplicationDto createDto)
        {
            var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);

            var jobApplication = new JobApplication
            {
                Company = createDto.Company,
                Position = createDto.Position,
                Status = createDto.Status,
                DateApplied = createDto.DateApplied,
                LastUpdated = DateTime.UtcNow,
                Notes = createDto.Notes,
                UserId = userId
            };

            _context.JobApplications.Add(jobApplication);
            await _context.SaveChangesAsync();

            return CreatedAtAction(
                nameof(GetJobApplication),
                new { id = jobApplication.Id },
                new JobApplicationDto
                {
                    Id = jobApplication.Id,
                    Company = jobApplication.Company,
                    Position = jobApplication.Position,
                    Status = jobApplication.Status,
                    DateApplied = jobApplication.DateApplied,
                    LastUpdated = jobApplication.LastUpdated,
                    Notes = jobApplication.Notes
                });
        }

        //[HttpPut("{id}")]
        //public async Task<IActionResult> UpdateJobApplication(int id, UpdateJobApplicationDto updateDto)
        //{
        //    var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);

        //    var jobApplication = await _context.JobApplications
        //        .FirstOrDefaultAsync(j => j.Id == id && j.UserId == userId);

        //    if (jobApplication == null)
        //    {
        //        return NotFound();
        //    }

        //    jobApplication.Status = updateDto.Status;
        //    if (!string.IsNullOrEmpty(updateDto.Notes))
        //    {
        //        jobApplication.Notes = updateDto.Notes;
        //    }
        //    jobApplication.LastUpdated = DateTime.UtcNow;

        //    await _context.SaveChangesAsync();

        //    return NoContent();
        //}

        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateJobApplication(int id, UpdateJobApplicationDto updateDto)
        {

            var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);

            var jobApplication = await _context.JobApplications
                .FirstOrDefaultAsync(j => j.Id == id && j.UserId == userId);
            //var jobApplication = await _context.JobApplications.FindAsync(id);

            if (jobApplication == null)
            {
                return NotFound();
            }

            // Update fields
            jobApplication.Status = updateDto.Status;
            jobApplication.Notes = updateDto.Notes;
            jobApplication.LastUpdated = DateTime.UtcNow; // Updating the last modified date

            _context.JobApplications.Update(jobApplication);
            await _context.SaveChangesAsync();

            // Convert entity to DTO for response
            var updatedDto = new JobApplicationDto
            {
                Id = jobApplication.Id,
                Company = jobApplication.Company,
                Position = jobApplication.Position,
                Status = jobApplication.Status,
                DateApplied = jobApplication.DateApplied,
                LastUpdated = jobApplication.LastUpdated,
                Notes = jobApplication.Notes
            };

            return Ok(updatedDto); // Return the updated DTO
        }


        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteJobApplication(int id)
        {
            var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);

            var jobApplication = await _context.JobApplications
                .FirstOrDefaultAsync(j => j.Id == id && j.UserId == userId);

            if (jobApplication == null)
            {
                return NotFound();
            }

            _context.JobApplications.Remove(jobApplication);
            await _context.SaveChangesAsync();

            return NoContent();
        }
    }

}
