import React, { useEffect, useState } from "react";
import NotificationService from "../../services/NotificationService";

const Notifications = () => {
    const [notifications, setNotifications] = useState([]);

    useEffect(() => {
        NotificationService.getNotifications().then((response) => setNotifications(response.data));
    }, []);

    const handleMarkAsRead = async (id) => {
        await NotificationService.markNotificationAsRead(id);
        setNotifications(notifications.filter((n) => n.id !== id));
    };

    return (
        <div className="container">
            <h2>Notifications</h2>
            <ul>
                {notifications.map((notif) => (
                    <li key={notif.id}>
                        {notif.message} - {new Date(notif.notificationDate).toLocaleString()}
                        <button onClick={() => handleMarkAsRead(notif.id)}>Mark as Read</button>
                    </li>
                ))}
            </ul>
        </div>
    );
};

export default Notifications;
