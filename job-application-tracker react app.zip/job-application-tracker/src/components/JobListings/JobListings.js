import React, { useEffect, useState } from "react";
import JobListingService from "../../services/JobListingService";
import ApplyJob from "../JobApplications/ApplyJob";

const JobListings = () => {
    const [jobListings, setJobListings] = useState([]);

    useEffect(() => {
        JobListingService.getJobListings().then((response) => setJobListings(response.data));
    }, []);

    return (
        <div className="container">
            <h2>Job Listings</h2>
            <ul className="list-group">
                {jobListings.map((job) => (
                    <li className="list-group-item" key={job.id}>
                        <strong>{job.position}</strong> at {job.company}
                        <ApplyJob jobId={job.id} />
                    </li>
                ))}
            </ul>
        </div>
    );
};

export default JobListings;
