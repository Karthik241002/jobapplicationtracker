import React, { useState } from "react";
import JobApplicationService from "../../services/JobApplicationService";

const ApplyJob = ({ jobId }) => {
    const [notes, setNotes] = useState("");

    const handleSubmit = async (e) => {
        e.preventDefault();
        await JobApplicationService.applyForJob({ jobListingId: jobId, notes });
        alert("Application Submitted!");
    };

    return (
        <div>
            <h3>Apply for Job</h3>
            <form onSubmit={handleSubmit}>
                <textarea value={notes} onChange={(e) => setNotes(e.target.value)} placeholder="Your cover letter..." required></textarea>
                <button type="submit">Submit</button>
            </form>
        </div>
    );
};

export default ApplyJob;
