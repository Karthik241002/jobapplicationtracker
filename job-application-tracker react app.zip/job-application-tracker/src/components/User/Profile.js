import React, { useEffect, useState } from "react";
import UserService from "../../services/UserService";

const Profile = () => {
    const [user, setUser] = useState({ username: "", email: "" });

    useEffect(() => {
        UserService.getUserProfile().then((response) => setUser(response.data));
    }, []);

    const handleChange = (e) => {
        setUser({ ...user, [e.target.name]: e.target.value });
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        await UserService.updateUserProfile(user);
        alert("Profile Updated!");
    };

    return (
        <div className="container">
            <h2>Profile</h2>
            <form onSubmit={handleSubmit}>
                <div className="mb-3">
                    <label>Username</label>
                    <input type="text" className="form-control" name="username" value={user.username} disabled />
                </div>
                <div className="mb-3">
                    <label>Email</label>
                    <input type="email" className="form-control" name="email" value={user.email} onChange={handleChange} required />
                </div>
                <button type="submit" className="btn btn-primary">Update Profile</button>
            </form>
        </div>
    );
};

export default Profile;
