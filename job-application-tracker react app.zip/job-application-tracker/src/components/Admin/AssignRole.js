import React, { useState } from "react";
import AdminService from "../../services/AdminService";

const AssignRole = () => {
    const [userId, setUserId] = useState("");

    const handleAssign = async () => {
        await AdminService.assignRole(userId, "ApplicationStatusManager");
        alert("Role Assigned Successfully");
    };

    return (
        <div className="container">
            <h2>Assign Role</h2>
            <input type="text" placeholder="User ID" value={userId} onChange={(e) => setUserId(e.target.value)} required />
            <button onClick={handleAssign}>Assign Role</button>
        </div>
    );
};

export default AssignRole;
