import React, { createContext, useState } from 'react';
import { login, logout, getCurrentUser } from '../services/AuthService'; // Correct import
import { useNavigate } from 'react-router-dom'

export const AuthContext = createContext(); // Create and export AuthContext

export const AuthProvider = ({ children }) => {
    const [token, setToken] = useState(localStorage.getItem('token'));
    const [user, setUser] = useState(token ? getCurrentUser() : null);
    const navigate = useNavigate();

    const updateUser = (newToken) => {
        setToken(newToken);
        localStorage.setItem('token', newToken);
        setUser(newToken ? getCurrentUser() : null);
    };

    const loginUser = async (credentials) => {
        try {
            const newToken = await login(credentials);
            updateUser(newToken);
            navigate('/');
        } catch (error) {
            console.error("Login failed:", error);
            throw error;
        }
    };

    const logoutUser = () => {
        logout();
        updateUser(null);
        navigate('/login');
    };

    const contextValue = {
        user,
        login: loginUser,
        logout: logoutUser,
        token,
        setToken: updateUser,
    };

    return (
        <AuthContext.Provider value={contextValue}>
            {children}
        </AuthContext.Provider>
    );
};

export const useAuth = () => {
    return React.useContext(AuthContext);
};