import axios from "axios";
import { jwtDecode } from 'jwt-decode';

const API_URL = process.env.REACT_APP_API_URL + "/Auth";

export const register = (username, email, password, isAdmin = false) => {
    return axios.post(`${API_URL}/register`, { username, email, password, isAdmin });
};

export const login = async (credentials) => {
    try {
        const response = await axios.post(`${API_URL}/login`, credentials);
        const token = response.data.token;
        localStorage.setItem("token", token);
        return token;
    } catch (error) {
        console.error("Login error:", error);
        throw error;
    }
};

export const logout = () => { // Corrected export
    localStorage.removeItem("token");
};

export const getCurrentUser = () => { // Corrected export
    const token = localStorage.getItem("token");
    if (!token) {
        return null;
    }
    try {
        return parseUser(token);
    } catch (error) {
        console.error("Invalid token:", error);
        localStorage.removeItem("token");
        return null;
    }
};

const parseUser = (token) => {
    console.log("Token to parse:", token);
    const decoded = jwtDecode(token);
    return {
        id: decoded.sub,
        username: decoded.name,
        roles: decoded.role ? (Array.isArray(decoded.role) ? decoded.role : [decoded.role]) : []
    };
};

export default { register, login, logout, getCurrentUser };

/*
import axios from "axios";
import { jwtDecode } from 'jwt-decode';

const API_URL = "https://localhost:7033/api/Auth";

const register = (username, email, password, isAdmin = false) => {
    return axios.post(`${API_URL}/register`, { username, email, password, isAdmin });
};

export const login = async (credentials) => {
    try {
        const response = await axios.post(API_URL + "/auth/login", credentials);
        const token = response.data.token; // Assuming the token is in response.data.token
        localStorage.setItem("token", token);
        return token;
    } catch (error) {
        console.error("Login error:", error);
        throw error;
    }
};

const logout = () => {
    localStorage.removeItem("user");
};

const getCurrentUser = () => {
    const storedUser = JSON.parse(localStorage.getItem("user"));
    return storedUser ? parseUser(storedUser.Token) : null;
};

const parseUser = (token) => {
    console.log("Token value:", token); // Add this line
    const decoded = jwtDecode(token);
    return {
        id: decoded.sub,
        username: decoded.name,
        roles: decoded.role ? (Array.isArray(decoded.role) ? decoded.role : [decoded.role]) : []
    };
};

export default { register, login, logout, getCurrentUser };
*/

