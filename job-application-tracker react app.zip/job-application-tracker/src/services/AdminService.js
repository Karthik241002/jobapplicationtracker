import axios from "axios";

const API_URL = "https://localhost:7033/api/Admin";

const assignRole = (userId, role) => axios.post(`${API_URL}/assignStatusUpdaterRole?userId=${userId}`, {});

export default { assignRole };
