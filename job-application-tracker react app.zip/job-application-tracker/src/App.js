// import React from "react";
// import { BrowserRouter as Router, Routes, Route, Navigate } from "react-router-dom"; // Import Navigate
// import { AuthProvider } from "./context/AuthContext";
// import Navbar from "./components/Navbar/Navbar";
// import Login from "./components/Auth/Login";
// import JobListings from "./components/JobListings/JobListings";
// import JobApplications from "./components/JobApplications/JobApplications";
// import Notifications from "./components/Notifications/Notifications";
// import AssignRole from "./components/Admin/AssignRole";
// import ProtectedRoute from "./components/Auth/ProtectedRoute";
// import Profile from "./components/User/Profile";
// import ChangePassword from "./components/User/ChangePassword";


// const App = () => {
//     return (
//         <Router>
//             <AuthProvider>
//                 <Navbar />
//                 <div className="container mt-3">
//                     <Routes>
//                         <Route path="/login" element={<Login />} />
//                         <Route path="/jobs" element={<ProtectedRoute element={<JobListings />} />} />
//                         <Route path="/applications" element={<ProtectedRoute element={<JobApplications />} />} />
//                         <Route path="/notifications" element={<ProtectedRoute element={<Notifications />} />} />
//                         <Route path="/admin/assign-role" element={<ProtectedRoute element={<AssignRole />} roles={["Admin"]} />} />
//                         <Route path="/profile" element={<ProtectedRoute element={<Profile />} />} />
//                         <Route path="/change-password" element={<ProtectedRoute element={<ChangePassword />} />} />
//                         <Route path="/" element={<Navigate to="/jobs" replace />} /> {/* Add this route */}
//                     </Routes>
//                 </div>
//             </AuthProvider>
//         </Router>
//     );
// };
